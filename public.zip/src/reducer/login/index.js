/*
Component Name: loginReducer
Author: Vikash Rawshan : 51904199
Description : This reducer is used to handle user data
*/
let initialState = {
    userData : {
        userName: '',
        userType: '',
        isLoggedin : false,
        isAuthenticated: true
    }
}

const loginReducer = (state= initialState, action) => {
    switch (action.type) {
        case "IS_USER_LOGGEDIN":
          return {
            ...state,
              userData: {
                ...state.userData,
                userName: action.payload.user_id,
                userType: action.payload.userType,
                isLoggedin : action.payload.status
              }
          };
        case "USER_LOGOUT":
           return{
              ...state,
              userData: {
                ...state.userData,
                isLoggedin : action.payload,
                isAuthenticated : true
              }
           }
        case "UPDATE_USER_DETAIL":
          console.log(action.payload,"RRRRRR");
        return{
          ...state,
          userData: {
            ...state.userData,
            userName: action.payload[0].userName,
            userType: action.payload[0].user_type,
            isLoggedin : true
          }
        }
        case "LOGIN_FAILED":
        return{
            ...state,
            userData: {
            ...state.userData,
            isAuthenticated : false
            }
        }
        default:
            return state;
    }
}
export default loginReducer;