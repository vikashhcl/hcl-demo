/*
Component Name: collegeReducer
Author: Vikash Rawshan : 51904199
Description : This reducer is used to handle college data
*/
let initialState = {
    requestStatus :false,
    isShowEnabled : false,
    erolledList : [],
    collegeList : [],
    userList : [],
    userAdded: false,
    isUserUpdated: false
}

const collegeReducer = (state= initialState, action) => {
    switch (action.type) {
        case "GET_USER_LIST":
          return {
            ...state,
            userList : action.payload
          }
        case "DELETE_USER":
          return {
            ...state,
            userList : action.payload
          }
        case "UPDATE_USER_LIST":
          return {
            ...state,
            isUserUpdated : action.payload
          }
        case "UPDATE_INSERTION_STATUS":
          return {
            ...state,
            userAdded : action.payload
          }
        case "UPDATE_COLLEGE_LIST":
          return {
            ...state,
            collegeList : action.payload
          }
        case "CLOSE_MODAL":
          return {
            ...state,
            isShowEnabled : action.payload
          }
          case "ENROLLED_LIST":
            return {
              ...state,
              erolledList : action.payload
            }
        case "UPDATE_REQUEST_STATUS":
          return {
            ...state,
            isShowEnabled : action.payload
          }
        
        case "UPDATE_USER_DETAIL":
          return{
            ...state,
            userData: {
              ...state.userData,
              userName: action.payload[0].userName,
              userType: action.payload[0].user_type,
              isLoggedin : true
            }
          }
        default:
          return state;
      }
 }
 export default collegeReducer;