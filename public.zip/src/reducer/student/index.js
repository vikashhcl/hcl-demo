/*
Component Name: loginReducer
Author: Vikash Rawshan : 51904199
Description : This reducer is used to handle student data
*/
let initialState = {
    isProcessCompleted : false,
    studentList :[]
}

const studentReducer = (state= initialState, action) => {
    switch (action.type) {
        case "REGISTER_STUDENT":
           return{
              ...state,
              isProcessCompleted: true
           }
        case "UPDATE_REGISTRATION_DETAIL":
            return{
            ...state,
            studentList : action.payload
            }
        case "UPDATE_STUDENT_DETAIL":
        return{
          ...state,
          isProcessCompleted : action.payload
        }
        default:
            return state;
    }
}
export default studentReducer;