/*
Component Name: subscribeReducer
Author: Vikash Rawshan : 51904199
Description : This reducer is used to handle subscriber data
*/
let initialState = {
    isProcessCompleted : false,
    subscribedList :[]
}

const subscribeReducer = (state= initialState, action) => {
    switch (action.type) {
        case "SUBSCRIBE_USER":
           return{
              ...state,
              isProcessCompleted: true
           }
        case "CLOSE_MODEL":
            return{
                ...state,
                isProcessCompleted: false
            }
        case "UPDATE_SUBSCRIBER_LIST":
            return{
                ...state,
                subscribedList : action.payload
            }
        default:
            return state;
    }
}
export default subscribeReducer;