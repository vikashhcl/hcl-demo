/*
Component Name: Store
Author: Vikash Rawshan : 51904199
Description : Here we are creating store and middleware
*/
import { createStore, applyMiddleware, combineReducers } from 'redux';
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';
import collegeReducer from '../reducer/college'; 
import loginReducer from '../reducer/login';
import studentReducer from '../reducer/student';
import subscribeReducer from '../reducer/student/subscribe';

const rootReducer = combineReducers({
  collegeReducer : collegeReducer,
  loginReducer : loginReducer,
  studentReducer : studentReducer,
  subscribeReducer : subscribeReducer
});

const Store = createStore(
  rootReducer,
    composeWithDevTools(
      applyMiddleware(thunk),
    )
)

export default Store;