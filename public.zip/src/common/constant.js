export const USER_DETAILS_API = "http://localhost:3030/user_details";
export const COLLEGE_LIST_API = "http://localhost:3030/college";
export const USER_REGISTER_API = "http://localhost:3030/userRegistration";
export const ENROLLED_API = "http://localhost:3030/enrolled";
export const SUBSCRIBE_API = "http://localhost:3030/subscribe";