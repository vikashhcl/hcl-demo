import {useSelector, useDispatch} from 'react-redux';
import {Box} from '@material-ui/core';
import {NavLink} from 'react-router-dom';
import { userLogout } from '../action/login';

const Header = (props) => {
    const {userData :{isLoggedin, userName, userType}} = useSelector(state => state.loginReducer);
    const dispatch = useDispatch();
    return (
        <Box display="flex" className="top-header">
            <Box p={1}>
                <NavLink to="/" className="navBarLink">Home</NavLink>
                {isLoggedin && <NavLink to="/collegelist" className="navBarLink">College List</NavLink>}
                {isLoggedin && <NavLink to="/enrolledlist" className="navBarLink">Enrolled Requests</NavLink>}
                {isLoggedin && userType === 1 && <NavLink to="/studentlist" className="navBarLink">Student List</NavLink>}
                {isLoggedin && userType === 1 && <NavLink to="/register" className="navBarLink">Register User</NavLink>}
                {isLoggedin && userType === 1 && <NavLink to="/subscriber" className="navBarLink">Subscriber List</NavLink>}
                
            </Box>
            <Box p={1}>                
               {
                    (isLoggedin) ? 
                    <NavLink to="" className="navBarLink" onClick={()=> dispatch(userLogout(false))}>{userName} : Logout</NavLink> : 
                    <NavLink to="/login" className="navBarLink">Login</NavLink>
               }
            </Box>
        </Box>
    );
}
export default Header;