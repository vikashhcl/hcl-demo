/*
Component Name: Login
Author: Vikash Rawshan : 51904199
Description : This is functional component used for default view
Key Feature : I used new Hook features like useState, useEffect, Material UI,Formik, and formik supporting library yup for valaidation
*/
import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { checkUSerAuth } from '../../action/login';
import {Button, Grid, Box} from '@material-ui/core';
import Alert from '@material-ui/lab/Alert';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { makeStyles } from '@material-ui/core/styles';
import * as Yup from 'yup';

const Login = (props) => {
    const [ state, updateState] = useState({userType : 0, userName : '', password : ''})
    const { loginData: {userData: { isLoggedin, isAuthenticated } }, history } = props;
    const myStyle = makeStyles(
        {
            inputBox : {
                width: '100%',
                padding: '8px',
                borderRadius: '2px',
                border: 'solid 1px #ccc',
                marginBottom : '5px',
                boxSizing: 'border-box'
            },
            error : {
                color: 'red'
            },
            button : {
                border: 0,
                backgroundColor: '#099fef',
                color: 'white',
                padding: '10px 20px',
                '&:hover':{
                    backgroundColor: 'rgb(74 91 187)',
                }
            },
            flexDirectionColumn :{
                flexDirection : 'column',
                justifyContent : 'center',
                margin: 'auto',
                height: '80vh'
            },
            formLabel:{
                color: '#7b7979',
                fontSize: '14px'
            }
        }
    )
    const classes = myStyle();
    
    useEffect(() => {
        if(isLoggedin){
            history.replace('./collegelist')
        }
    })

    /*
    Validation Schema Name: DisplayingErrorMessagesSchema
    Author: Vikash Rawshan : 51904199
    Description : Here we are creating validation schema for formik form validation
    */
    const DisplayingErrorMessagesSchema = Yup.object().shape({
        username: Yup
            .string()
            .required('User name is required'),
        password: Yup
            .string()
            .max(4, 'Minimum 4 characters are required')
            .required('Password is required'),
    });
    
    /*
    Function Name: handleOnChange
    Author: Vikash Rawshan : 51904199
    Description : This function is used to update username/password state when you typein in user name and password field
    */
    const handleOnChange = (e) => {
        const {name, value} = e.target;
        updateState({...state, [name] : value})
    }

    /*
    Function Name: clickOnSubmit
    Author: Vikash Rawshan : 51904199
    Description : This function is used to authenticate user input and login
    */
    const clickOnSubmit = () => {
        const data = {
            user_id: state.userName,
            password: state.password,
        }
        checkUSerAuth(data);
    }
    
    return (
        <>
            <Box
                display="flex"
                flexWrap="wrap"
                p={1}
                m={1}
                justifyContent = "center"
                css={{ maxWidth: '100%' }}
            >
                <Formik
                    initialValues={{
                        username: '',
                        password: ''
                    }}
                    validationSchema={DisplayingErrorMessagesSchema}
                    onSubmit={values => {
                        props.checkUSerAuth(values)
                    }}
                    >
                    {({ errors, touched }) => (
                        <Grid xs={12} sm={6} md={4} mg={4} lg={4}>
                            
                        <Form className={classes.flexDirectionColumn}>
                        <h2 style={{textAlign: 'center'}}>Login Portal</h2>
                            <label className={classes.formLabel}>User Name</label>
                            <Field name="username" type="text" className={classes.inputBox}/>
                            <ErrorMessage name="username" component="div" className={"invalid-feedback "+ classes.error} />
                            <label className={classes.formLabel}>Password</label>
                            <Field name="password" type="password" className={classes.inputBox}/>
                            <ErrorMessage name="password" component="div" className={"invalid-feedback "+ classes.error} />
                            <Button type="submit" className={classes.button}>Submit</Button><br/>
                            {!isAuthenticated && <Alert severity="error">Oops! Something went wrong!</Alert>}
                        </Form>
                        </Grid>
                    )}
                </Formik>
            </Box>
            <Box
                display="flex"
                flexWrap="wrap"
                p={1}
                m={1}
                justifyContent = "center"
                css={{ maxWidth: '100%' }}
            >
                
            </Box>
        </>
     );
}

const mapStateToProps = (state) => {
    return {
       collegeData: state.collegeReducer,
       loginData: state.loginReducer,
    };
 };
 const mapDispatchToProps = (dispatch) => {
    return {
       checkUSerAuth: (data) => dispatch(checkUSerAuth(data))
    }
 }
export default connect(mapStateToProps, mapDispatchToProps)(Login);