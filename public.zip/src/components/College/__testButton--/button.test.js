import { render } from '@testing-library/react';
import Button from '../button';
const data = {id: 1, requestStatus: 'pending', userType:0}

const onRemoveRequest = (id) => {
    return {
        id : id,
        userName : 'vikash@hcl',
        userType : 0
    }
}

const changeUserRequestStatus = (id, status) => {
    return {id : id, status:status}
}

it("renders without crashing", ()=>{
    render(<Button data={data} onRemoveRequest={onRemoveRequest} changeRequestStatus={changeUserRequestStatus}></Button>)
})