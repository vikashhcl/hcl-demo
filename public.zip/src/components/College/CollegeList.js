/*
Component Name: CollegeList
Author: Vikash Rawshan : 51904199
Description : This is functional component used for default view
Key Feature : I used new Hook features like useState, useEffect, and Material UI
*/
import {useState, useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import Card from '@material-ui/core/Card';
import PageviewIcon from '@material-ui/icons/Pageview';
import { sendRequest, getEnrolledList, getCollegeList } from '../../action/college';
import {Select, FormControl, MenuItem, InputLabel, DialogTitle, Dialog, DialogContent, DialogActions, Box, CardActionArea, CardActions, CardContent, CardMedia, Button, Typography} from '@material-ui/core';

const useStyles = makeStyles({
    root: {
      maxWidth: 230,
    },
    media: {
      height: 140,
    },
    button: {
        flexDirection: 'row-reverse'
    },
    forntSizeH2: {
        fontSize: '1rem'
    },
    dropDown :{
        width: '150px'
    }
});

  const CollegeList = (props) => {
    const [state, setState] = useState({city:'all', collegeBranch:'', visible: false, collegeDetails :{}});  
    const { loginData : { userData: {isLoggedin, userName, userType}},collegeData : {collegeList, erolledList, isShowEnabled}, history } = props;
    const classes = useStyles();

    if(!isLoggedin){
        history.replace('./')
    }

    useEffect(() => {
        /*
        Validation Schema Name: getCollegeList
        Author: Vikash Rawshan : 51904199
        Description : This function will return college list based on city
        */
        state.city != "" && props.getCollegeList(state.city);

        /*
        Validation Schema Name: getEnrolledList
        Author: Vikash Rawshan : 51904199
        Description : This function will return list of college for that student has requested for enrollment based on user type
                      0=> normal user
                      1=> admin
        */
        if(userType === 0){
            props.getEnrolledList(userName);
        }else{
            props.getEnrolledList();
        }
    },[state.city])
  
    /*
    Author: Vikash Rawshan : 51904199
    Description : Here we are creating an array of requested college list for enrollment whose request status != rejected
    */
    const requestedCollegeID = [];
    erolledList && erolledList.map((item) => {
        if(item.requestStatus !== 'rejected'){
            requestedCollegeID.push(item.college_id)
        }
    })

    /*
    Function Name: handleOnChange
    Author: Vikash Rawshan : 51904199
    Description : This function is used to update city when user select city from dropdown
    */
    const handleOnChange = (e) => {
        const {name, value} = e.target;
        setState({...state, [name] : value})
    }

    /*
    Function Name: onClickRequest
    Author: Vikash Rawshan : 51904199
    Description : This function is used to send request for enrollment and validation branch also
    */
    const onClickRequest = (requestData) => {
        requestData.branch !== "" ? props.sendRequest(requestData) : alert("Oops! Select Branch")
    }

    /*
    Function Name: setModalHide
    Author: Vikash Rawshan : 51904199
    Description : This function is used to update the status of visible as false.
                  Based on visible true/false we are showing/hiding model box.
    */
    const setModalHide = () =>{
        setState({...state, visible: false})
    }

    /*
    Function Name: showCollegeDetails
    Author: Vikash Rawshan : 51904199
    Description : This function is used to update the status of visible as false.
                  Based on visible true/false we are showing/hiding model box.
                  And updating collegeDetails. collegeDetails object is passed to model box.
    */
    const showCollegeDetails = (data) =>{
        setState({...state, collegeDetails: data, visible: true});        
    }
    return ( 
        <>
            <Box
                display="flex"
                flexWrap="wrap"
                p={1}
                m={1}
                css={{ maxWidth: '100%' }}
            >
                <Box p={1} key="1" flex="0 0 100%">
                    <h2 style={{textAlign: 'center'}}>College List</h2>
                    <FormControl className={classes.dropDown}>
                        <InputLabel id="demo-customized-select-label">Select city</InputLabel>
                        <Select
                        labelId="demo-customized-select-label"
                        id="demo-customized-select"
                        name="city"
                        onChange={ (e) => handleOnChange(e)}
                        value={state.city}
                        >
                            <MenuItem value={"all"}>All</MenuItem>
                            <MenuItem value={"Chennai"}>Chennai</MenuItem>
                            <MenuItem value={"Bangalore"}>Bangalore</MenuItem>
                            <MenuItem value={"Delhi"}>Delhi</MenuItem>
                        </Select>
                    </FormControl>
                </Box>
                {collegeList && collegeList.map((college, index) => {
                    const collegeDetals = {
                        userName : userName,
                        userType : userType,
                        college_id : college.id,
                        photo : college.photo,
                        title : college.college_name,
                        city : college.city,
                        branch : state.collegeBranch,
                        collegeCode : college.collegeCode,
                        contact : college.contact,
                        requestStatus : 'pending'
                    }
                    return (<Box p={1}  key={index}>
                        <Card className={classes.root}>
                            <CardActionArea>
                                <CardMedia
                                className={classes.media}
                                image={college.photo}
                                title="Contemplative Reptile"
                                />
                                <CardContent>
                                    <Typography gutterBottom variant="h5" component="h2" className={classes.forntSizeH2}>
                                    {college.college_name}
                                    </Typography>
                                    <Typography variant="body2" color="textSecondary" component="p">
                                        City: {college.city}
                                    </Typography>
                                    <Typography>
                                        <FormControl className={classes.dropDown}>
                                            <InputLabel id="demo-customized-select-label">Select Branch</InputLabel>
                                            <Select
                                            labelId="demo-customized-select-label"
                                            id="demo-customized-select"
                                            name="collegeBranch"
                                            onChange={ (e) => handleOnChange(e)}
                                            >
                                                {college.branch && college.branch.map((item, index)=>{
                                                    return (
                                                        <MenuItem value={item} key={index}>{item}</MenuItem>
                                                    )
                                                })}
                                            </Select>
                                        </FormControl>
                                    </Typography>
                                </CardContent>
                            </CardActionArea>
                            <CardActions className={classes.button}>
                                <Button size="small" color="primary" onClick={()=> showCollegeDetails(college)}>
                                    <PageviewIcon/>
                                </Button>
                                {userType !==1 ?
                                 requestedCollegeID.includes(college.id)
                                    ? <span>Requested</span>
                                    :<Button id={college.id} size="small" color="primary" onClick={() => onClickRequest(collegeDetals)}>Request</Button>
                                        :
                                        <Button id={college.id} size="small" color="primary" onClick={() => onClickRequest(collegeDetals)}>Request</Button>
                                    } 
                                
                            </CardActions>
                        </Card>
                    </Box>
                )})}
               {collegeList.length == 0 && <Box flex="0 0 100%" m={2} textAlign="center">Data not found</Box>}
            </Box>
        
            <Dialog
                    open={state.visible}
                    onClose={setModalHide}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                <DialogTitle id="customized-dialog-title">
                    {state.collegeDetails && state.collegeDetails.college_name}
                </DialogTitle>
                <DialogContent dividers>
                    {
                    state.collegeDetails &&
                    <>
                        <CardMedia
                            className={classes.media}
                            image={state.collegeDetails.photo}
                            title="Contemplative Reptile"
                        /><br/>
                        Branch : <b>{state.collegeDetails.branch && state.collegeDetails.branch.join()}<br/><br/></b>
                        City : <b>{state.collegeDetails.city} <br/><br/></b>
                        College Code : <b>{state.collegeDetails.collegeCode} <br/><br/></b>
                        Contact Number : <b>{state.collegeDetails.contact} <br/></b>
                    </>
                    }
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={setModalHide} color="primary">
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
        </>
     );
}

const mapStateToProps = (state) => {
    return {
       collegeData: state.collegeReducer,
       loginData: state.loginReducer,
    };
 };

const mapDispatchToProps = (dispatch) => {
    return {
        sendRequest : (data) => dispatch (sendRequest(data)),
        getEnrolledList : (data) => dispatch (getEnrolledList(data)),
        getCollegeList : (data) => dispatch (getCollegeList(data))
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(CollegeList);