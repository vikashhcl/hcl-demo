/*
Component Name: EnrolledList
Author: Vikash Rawshan : 51904199
Description : This is functional component is used to show Enrolled List
Key Feature : I used new Hook features like useState, useEffect, useSelector, useDispatch, and Material UI
*/
import {useState, useEffect} from 'react';
import {useSelector, useDispatch} from 'react-redux';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import { getEnrolledList, cancelStudentRequest, changeRequestStatus } from '../../action/college';
import StatusButton from './button';
import {Box, CardActionArea, CardActions, CardContent, CardMedia, Typography} from '@material-ui/core';

const useStyles = makeStyles({
    root: {
      maxWidth: 230,
    },
    media: {
      height: 140,
    },
    button: {
        flexDirection: 'row-reverse',
        justifyContent: 'space-between'
    },
    forntSizeH2: {
        fontSize: '1rem'
    },
    dropDown :{
        width: '100px'
    }
});

const EnrolledList = (props) =>{
    const [state, setState] = useState({collegeBranch:'', visible: false, collegeDetails :{}});  
    const {erolledList} = useSelector(state => state.collegeReducer);
    const {userData : {isLoggedin, userName, userType}} = useSelector(state => state.loginReducer);
    const dispatch = useDispatch();
    const classes = useStyles();
    
    if(!isLoggedin){
        props.history.replace('./')
    }

    /*
    Function Name: getEnrolledList
    Author: Vikash Rawshan : 51904199
    Description : This function is used to get enrolled college list
    */
    useEffect(() => {
        getEnrolledList();
    },[])

    /*
    Function Name: getEnrolledList
    Author: Vikash Rawshan : 51904199
    Description : This function is used to update visible as false.
                  Based on visible true/false we are showing/hiding model box
    */
    const setModalHide = () =>{
        setState({...state, visible: false})
    }

    /*
    Function Name: showCollegeDetails
    Author: Vikash Rawshan : 51904199
    Description : This function is used to update the status of visible as false.
                  Based on visible true/false we are showing/hiding model box.
                  And updating collegeDetails. collegeDetails object is passed to model box.
    */
    const showCollegeDetails = (data) =>{
        setState({...state, collegeDetails: data, visible: true});        
    }

    /*
    Function Name: onRemoveRequest
    Author: Vikash Rawshan : 51904199
    Description : This function is used to cancel student request for a particular college enrollment.
    */
    const onRemoveRequest = (id) => {
        const data = {
            id : id,
            userName : userName,
            userType : userType
        }
        dispatch(cancelStudentRequest(data))
    }

    /*
    Function Name: changeUserRequestStatus
    Author: Vikash Rawshan : 51904199
    Description : This function is used to the status of request for a particular college enrollment.
    */
    const changeUserRequestStatus = (id, status) => {
        dispatch(changeRequestStatus({id : id, status:status}))
    }

    return(
        <Box
            display="flex"
            flexWrap="wrap"
            p={1}
            m={1}
            css={{ maxWidth: '100%' }}
        >
            <Box flex="0 0 100%"><h2 style={{textAlign: 'center'}}>Enrolled Request College List</h2></Box>
            {erolledList && erolledList.map((college, index) => {
                return (<Box p={1}  key={index}>
                    <Card className={classes.root}>
                        <CardActionArea>
                            <CardMedia
                            className={classes.media}
                            image={college.photo}
                            title="Contemplative Reptile"
                            />
                            <CardContent>
                                <Typography gutterBottom variant="h5" component="h2" className={classes.forntSizeH2}>
                                {college.college_name}
                                </Typography>
                                <Typography>
                                    City: {college.city}
                                </Typography>
                                <Typography variant="body2" color="textSecondary" component="p">
                                    Branch: {college.branch}
                                </Typography>
                                <Typography variant="body2" color="textSecondary" component="p">
                                    College Code: {college.collegeCode}
                                </Typography>
                                <Typography variant="body2" color="textSecondary" component="p">
                                    Contact Number: {college.contact}
                                </Typography>
                            </CardContent>
                        </CardActionArea>
                        <CardActions className={classes.button}>
                            <StatusButton 
                                data={college} 
                                onRemoveRequest={onRemoveRequest} 
                                changeRequestStatus={changeUserRequestStatus} 
                                userType={userType}
                            />
                        </CardActions>
                    </Card>
                </Box>
            )})}
            {erolledList.length == 0 && <Box flex="0 0 100%" m={2} textAlign="center">Data not found</Box>}
        </Box>
    )
}

export default EnrolledList;