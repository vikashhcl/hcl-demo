/*
Component Name: StatusButton
Author: Vikash Rawshan : 51904199
Description : This is functional component used for request status button
*/
import {Button} from '@material-ui/core';
const StatusButton = (props) => {
    const {changeRequestStatus, onRemoveRequest, data : {id, requestStatus}, userType} = props;
        if(userType === 0){
            if(requestStatus === 'pending') {
                return <span id={id} style={{color:'#ffc107'}}>Request Pending</span>
            }
            else if(requestStatus === 'approved'){
                return <span id={id} style={{color:'#28a745'}}>Approved</span>
            }else{
                return <><span id={id} style={{color:'#ef7070'}}>Rejected</span><Button id={id} size='sm' variant="contained" color="primary" style={{marginLeft:'5px'}} onClick={() => onRemoveRequest(id)}>Remove</Button></>
            }
        }else{
            if(requestStatus === 'pending') {
                return (
                    <>
                        <Button id={id} size='sm' variant="contained" color="primary" onClick={() => changeRequestStatus(id, 'approved')}>Approve</Button>
                        <Button id={id} size='sm' variant='contained' color="secondary" style={{marginLeft:'0'}} onClick={() => changeRequestStatus(id, 'rejected')}>Reject</Button>
                    </>
                )
            }else if(requestStatus === 'approved'){
                return <span id={id} style={{color:'#1888ff'}}>Approved</span>
            }else{
                return <span id={id} style={{color:'#ef7070'}}>Rejected</span>
            }
        }
}
 
export default StatusButton;