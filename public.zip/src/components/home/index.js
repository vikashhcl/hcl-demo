/*
Component Name: Home
Author: Vikash Rawshan : 51904199
Description : This is functional component used for default view
Key Feature : I used new Hook features like useState, useDispatch, useSelector, Material UI, and Cutome CSS
*/
import {useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {subscribeUser, closeModel} from '../../action/student/subscribe';
import {Dialog, DialogContent, DialogActions, Button, Grid} from '@material-ui/core';
import Alert from '@material-ui/lab/Alert';
import { makeStyles } from '@material-ui/core/styles';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

const Home = (props) => {
    const [state, updateState] = useState({email:''})
    const {isProcessCompleted} = useSelector(state => state.subscribeReducer);

    const dispatch = useDispatch();

    const myStyle = makeStyles(
        {
            inputBox : {
                width: '100%',
                padding: '8px',
                borderRadius: '2px',
                border: 'solid 1px #ccc',
                marginBottom : '5px',
                boxSizing: 'border-box'
            },
            error : {
                color: 'red'
            },
            button : {
                marginLeft: '15px',
                width: '170px',
                backgroundColor: 'white',
                '&:hover':{
                    backgroundColor: 'rgb(74 91 187)',
                },
                height: '45px'
            }
        }
    )
    const classes = myStyle();

    /*
    Validation Schema Name: DisplayingErrorMessagesSchema
    Author: Vikash Rawshan : 51904199
    Description : Here we are creating validation schema for formik form validation
    */
   const DisplayingErrorMessagesSchema = Yup.object().shape({
        email: Yup
            .string()
            .required('User name is required')
    });

    /*
    Function Name: handleOnChange
    Author: Vikash Rawshan : 51904199
    Description : This function is used to update email state when you typein in email field
    */
    const handleOnChange = (e) => {
        const {name, value} = e.target;
        updateState({...state, [name] : value});
    }

    /*
    Function Name: subscribe
    Author: Vikash Rawshan : 51904199
    Description : This function is used to subscribe user
    */
    const subscribe = () =>{
        state.email!="" ? dispatch(subscribeUser(state.email)) : alert("Email is required")
    }

    /*
    Function Name: handleClose
    Author: Vikash Rawshan : 51904199
    Description : This function is used to update open state as false. Once open state is false, Model box will close.
                   Here we are dispatching and action closeModel
    */
    const handleClose = () =>{
        dispatch(closeModel())
        updateState({...state, email : ''});
    }
    return ( 
        <>
            <div className="banner-container">
                <div className="container-footer-signin">
                    <h1 className="banner-header-h1">
                    HCL Technologies is an Indian multinational technology company 
                    that specializes in information technology services and consulting!
                    </h1>
                    <div>                    
                        <img src="https://res-3.cloudinary.com/crunchbase-production/image/upload/c_lpad,h_256,w_256,f_auto,q_auto:eco/zqct5xvb6ewsodeywmfj"/>
                    </div>
                </div>
            </div>
            <section className="padding-top-bottom-100">
                <h1>What people are saying...</h1>
                <div className="content-container">
                    <div className="box-content col3">
                        <img className="round-img" src="https://startbootstrap.github.io/startbootstrap-landing-page/img/testimonials-1.jpg"/>
                        <h3>Margaret E.</h3>
                        <p>"This is fantastic! Thanks so much guys!"</p>
                    </div>
                    <div className="box-content col3">
                        <img className="round-img" src="https://startbootstrap.github.io/startbootstrap-landing-page/img/testimonials-2.jpg"/>
                        <h3>Fred S.</h3>
                        <p>"Bootstrap is amazing. I've been using it to create lots of super nice landing pages."</p>
                    </div>
                    <div className="box-content col3">
                        <img className="round-img" src="https://startbootstrap.github.io/startbootstrap-landing-page/img/testimonials-3.jpg"/>
                        <h3>Sarah W.</h3>
                        <p>"Thanks so much for making these free resources available to us!"</p>
                    </div>
                </div>
            </section>
            <div>
                <section>
                    <div className="row">
                        <div className="box-content col2">
                            <h1>Fully Responsive Design</h1>
                            <p>When you use a theme created by Start Bootstrap, you know that the theme will look great on any device, whether
                                it's a city, tablet, or desktop the page will behave responsively!</p>
                        </div>
                        <div className="box-content col2-img">
                            <img src="https://startbootstrap.github.io/startbootstrap-landing-page/img/bg-showcase-1.jpg"/>
                        </div>
                    </div>

                    <div className="row">
                        <div className="box-content col2-img">
                            <img src="https://startbootstrap.github.io/startbootstrap-landing-page/img/bg-showcase-2.jpg"/>
                        </div>
                        <div className="box-content col2">
                            <h1>Updated For Bootstrap 4</h1>
                            <p>Newly improved, and full of great utility classes, Bootstrap 4 is leading the way in mobile responsive web development!
                                All of the themes on Start Bootstrap are now using Bootstrap 4!</p>
                        </div>
                    </div>

                    <div className="row">
                        <div className="box-content col2">
                            <h1>Easy to Use & Customize</h1>
                            <p>Landing Page is just HTML and CSS with a splash of SCSS for users who demand some deeper customization options. Out of the box,
                                just add your content and images, and your new landing page will be ready to go!</p>
                        </div>
                        <div className="box-content col2-img">
                            <img src="https://startbootstrap.github.io/startbootstrap-landing-page/img/bg-showcase-3.jpg"/>
                        </div>
                    </div>
                </section>
                <div className="banner-container">
                    <div className="container-footer-signin footer-banner">
                        <h1 style={{textAlign: 'center'}}>Ready to get started? Subscribe now!</h1>
                        <div>                    
                            <form>
                                <div><input required type="email" name="email" placeholder="Enter your email!" onChange={(e)=>handleOnChange(e)} value={state.email}/></div>
                                <div className="margin-top-10"><button type="button" onClick={subscribe}>Subscribe</button></div>
                            </form>

                            {/* <Formik
                                initialValues={{
                                    email: ''
                                }}
                                validationSchema={DisplayingErrorMessagesSchema}
                                onSubmit={values => {
                                    dispatch(subscribeUser(values))
                                }}
                                >
                                {({ errors, touched }) => (
                                    <Grid xs={12}>                                        
                                        <Form>
                                            <ErrorMessage name="email" component="div" className={"invalid-feedback "+ classes.error} style={{marginLeft:'5px'}}/>
                                            <Field name="email" type="text" placeholder="Enter email..." className={classes.inputBox} onChange={(e)=>handleOnChange(e)} value={state.email}/>
                                            <Button type="submit" className={classes.button}>Subscribe</Button>
                                        </Form>
                                    </Grid>
                                )}
                            </Formik> */}
                        </div>
                    </div>
                </div>
            </div>

            <Dialog
                    open={isProcessCompleted && isProcessCompleted}
                    onClose={handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                <DialogContent dividers>
                    Subscribed Successfully!
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={handleClose} color="primary">
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
        </>
     );
}
 
export default Home;