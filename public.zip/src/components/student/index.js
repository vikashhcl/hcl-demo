/*
Component Name: Register
Author: Vikash Rawshan : 51904199
Description : This is functional component used for student registration
Key Feature : I used new Hook features like useState, useEffect,useSelector, useDispatch, Material UI,Formik, and formik supporting library yup for valaidation
*/
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { makeStyles } from '@material-ui/core/styles';
import {useSelector, useDispatch} from 'react-redux';
import {studentRegister, updateStudentDetails} from '../../action/student';
import {Dialog, DialogContent, DialogActions, Box, Button} from '@material-ui/core';

const Register = (props) => { 
    const myStyle = makeStyles(
        {
            inputBox : {
                width: '100%',
                padding: '8px',
                borderRadius: '2px',
                border: 'solid 1px #ccc'
            },
            error : {
                color: 'red'
            },
            button : {
                border: 0,
                backgroundColor: '#099fef',
                color: 'white',
                padding: '10px 20px'
            },
            reset : {
                backgroundColor: '#e89a9a',
                marginLeft: '10px'
            },
            registerForm : {
                flex: props ? props.flex : '0 0 40%',
                // flexDirection : 'column' 
                flexFlow: 'row wrap',
                justifyContent: 'center'  
            },
            boxClass : {
                marginLeft: '10px'
            },
            buttonClass: {
                display: 'flex',
                justifyContent : 'center'
            }
        }
    )

    /*
    Validation Schema Name: useSelector
    Author: Vikash Rawshan : 51904199
    Description : Here we are usign a hook function useSelector to get related data from store
    */
    const {isProcessCompleted} = useSelector(state => state.studentReducer);

    /*
    Validation Schema Name: useDispatch
    Author: Vikash Rawshan : 51904199
    Description : Here we are usign a hook function useDispatch to dispatch action.
    */
    const dispatch = useDispatch();
    const { history : {replace}, isstudentListPage} = props;
    let id= props.data && props.data.id;

    /*
    Validation Schema Name: registerUser
    Author: Vikash Rawshan : 51904199
    Description : Here we are usign this function to register student.
    */
    const registerUser = (data) =>{
        isstudentListPage ? dispatch(studentRegister(id, data)) : dispatch(studentRegister(null, data))
    }

    /*
    Validation Schema Name: handleClose
    Author: Vikash Rawshan : 51904199
    Description : Here we are usign this function to close model box and redirect to home or student list page based on condition.
    */
    const handleClose = () => {
        dispatch(updateStudentDetails(false))
        isstudentListPage ? replace('/') : replace('/studentlist')
    };
    const classes = myStyle();
        return (
            <Box
                display="flex"
                flexWrap="wrap"
                p={1}
                m={1}
                justifyContent = "center"
                css={{ maxWidth: '100%' }}
            >
            <Box p={1} flex="0 0 100%"><h2 style={{textAlign: 'center'}}>Registration Form</h2></Box>
            <Formik
                initialValues={{
                    name: props.data ? props.data.name : '',
                    address: props.data ? props.data.address : '',
                    email: props.data ? props.data.email : '',
                    age: props.data ? props.data.age : '',
                    phone: props.data ? props.data.phone : '',
                    gender: props.data ? props.data.gender : ''
                }}
                validationSchema={Yup.object().shape({
                    name: Yup.string()
                        .required('Name is required'),
                    address: Yup.string()
                        .required('Address is required'),
                    email: Yup.string()
                        .email('Email is invalid')
                        .required('Email is required'),
                    age: Yup.string()
                        .required('Age is required'),
                    phone: Yup.string()
                        .min(10,'Invalid Phone Number')
                        .max(10,'Invalid Phone Number')
                        .required('Phone Number is required'),
                    gender: Yup.string()
                        .required('Gender is required'),
                })}
                onSubmit={fields => {
                    registerUser(fields)                                  
                }}
                render={({ errors, status, touched }) => (
                    <Form className={classes.registerForm}>
                        <Box p={1} flex="0 0 33.33%" className={classes.boxClass}>
                            <label htmlFor="firstName">Name</label>
                            <Field name="name" type="text" className={'form-control ' + (errors.name && touched.name ? ' is-invalid ' + classes.inputBox : classes.inputBox)} />
                            <ErrorMessage name="name" component="div" className={"invalid-feedback "+ classes.error} />
                        </Box>
                        <Box p={1} flex="0 0 33.33%" className={classes.boxClass}>
                            <label htmlFor="address">Address</label>
                            <Field name="address" type="text" className={' form-control ' + (errors.address && touched.address ? ' is-invalid ' + classes.inputBox : classes.inputBox)} />
                            <ErrorMessage name="address" component="div" className={"invalid-feedback "+ classes.error} />
                        </Box>
                        <Box p={1} flex="0 0 33.33%" className={classes.boxClass}>
                            <label htmlFor="email">Email</label>
                            <Field name="email" type="text" className={' form-control ' + (errors.email && touched.email ? ' is-invalid ' + classes.inputBox : classes.inputBox)} />
                            <ErrorMessage name="email" component="div" className={"invalid-feedback "+ classes.error} />
                        </Box>
                        <Box p={1} flex="0 0 33.33%" className={classes.boxClass}>
                            <label htmlFor="age">Age</label>
                            <Field name="age" type="age" className={' form-control ' + (errors.age && touched.age ? ' is-invalid ' + classes.inputBox : classes.inputBox)} />
                            <ErrorMessage name="age" component="div" className={"invalid-feedback "+ classes.error} />
                        </Box>
                        <Box p={1} flex="0 0 33.33%" className={classes.boxClass}>
                            <label htmlFor="phone">Phone Number</label>
                            <Field name="phone" type="text" className={' form-control ' + (errors.phone && touched.phone ? ' is-invalid ' + classes.inputBox : classes.inputBox)} />
                            <ErrorMessage name="phone" component="div" className={"invalid-feedback "+ classes.error} />
                        </Box>
                        <Box p={1} flex="0 0 33.33%" className={classes.boxClass}>
                            <label htmlFor="gender">Gender</label><br/><br/>
                            <label htmlFor="gender">Male</label>
                            <Field name="gender" type="radio" className={' form-control ' + (errors.gender && touched.gender ? ' is-invalid ' : '')} value="Male" />
                            <label htmlFor="gender">Female</label>
                            <Field name="gender" type="radio" className={' form-control ' + (errors.gender && touched.gender ? ' is-invalid ' : '')} value="Female" />
                            <ErrorMessage name="gender" component="div" className={"invalid-feedback "+ classes.error} />
                        </Box>
                        <Box p={1} flex="0 0 33.33%" className={classes.buttonClass}>
                            {
                                isstudentListPage ? <Button type="submit" className={"btn btn-primary mr-2 " + classes.button}>Update</Button>: 
                                <><Button type="submit" className={"btn btn-primary mr-2 " + classes.button}>Register</Button>
                                <Button type="reset" className={"btn btn-secondary " + classes.button + " "+ classes.reset}>Reset</Button></>
                            }
                        </Box>
                    </Form>
                )}
            />

                <Dialog
                        open={isProcessCompleted && isProcessCompleted}
                        onClose={handleClose}
                        aria-labelledby="alert-dialog-title"
                        aria-describedby="alert-dialog-description"
                    >
                    <DialogContent dividers>
                        {isstudentListPage ? 'Student Data Updated Succefully!' : 'Student Registered Succefully!'}
                    </DialogContent>
                    <DialogActions>
                        <Button autoFocus onClick={handleClose} color="primary">
                            Close
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>
        )
    }
export default Register;