/*
Component Name: StudentList
Author: Vikash Rawshan : 51904199
Description : This is functional component used for student registration
Key Feature : I used new Hook features like useState, useEffect,useSelector, useDispatch, and Material UI
*/
import {useState, useEffect} from 'react';
import {useSelector, useDispatch} from 'react-redux';
import {getStudentList, deleteStudentEntry} from '../../action/student';
import { makeStyles } from '@material-ui/core/styles';
import {Dialog, DialogContent, DialogActions, Button, Table,TableBody,TableCell, TableContainer, TableHead, TableRow, Paper} from '@material-ui/core';
import EditIcon from '@material-ui/icons/Edit';
import DeleteIcon from '@material-ui/icons/Delete';
import Register from '../student';

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
  trBoldText : {
    fontWeight: 600
  },
  cursorStyle :{
    cursor : 'pointer'
  }
});

const StudentList = (props) => {
  const [state, updateState] = useState({studentData : {}, open:false});
  const classes = useStyles();  
  const {studentList} = useSelector(state => state.studentReducer);
  const {userData : {isLoggedin}} = useSelector(state => state.loginReducer);
  const dispatch = useDispatch();

  if(!isLoggedin){
      props.history.replace('./')
  }

  /*
  Validation Schema Name: getStudentList
  Author: Vikash Rawshan : 51904199
  Description : Here we are usign this action dispatcher function to get registered student list.
  */
  useEffect(()=>{
    dispatch(getStudentList())
  },[]);

  /*
  Validation Schema Name: editStudent
  Author: Vikash Rawshan : 51904199
  Description : Here we are usign this function to filter student details based on student id and update studentData.
                studentData is used to display data in edit form
  */
  const editStudent = (id) =>{
    const studentData = studentList && studentList.filter((data)=>{
      return data.id === id;
    })
    updateState({...state, studentData : studentData[0], open : true});
  }

  /*
  Validation Schema Name: deleteStudent
  Author: Vikash Rawshan : 51904199
  Description : Here we are usign this function to dispatch action dispatcher deleteStudentEntry to delete particular user
  */
  const deleteStudent = (id) =>{
    let isConfirm = window.confirm('Are you sure, you want to delete this student details');
    isConfirm && dispatch(deleteStudentEntry(id))
  }

  /*
  Validation Schema Name: handleClose
  Author: Vikash Rawshan : 51904199
  Description : Here we are usign this function to close model box
  */
  const handleClose = () => {
    updateState({...state, open: false})
  };
  
  return (
    <>
      <TableContainer component={Paper}>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
            <TableCell align="center" colSpan={8} className={classes.trBoldText}>
                Student List
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className={classes.trBoldText}>Name</TableCell>
              <TableCell align="left" className={classes.trBoldText}>Email ID</TableCell>
              <TableCell align="left" className={classes.trBoldText}>Phone Number</TableCell>
              <TableCell align="left" className={classes.trBoldText}>Age</TableCell>
              <TableCell align="left" className={classes.trBoldText}>Gender</TableCell>
              <TableCell align="left" className={classes.trBoldText}>Address</TableCell>
              <TableCell align="left" className={classes.trBoldText}>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {studentList.map((row, index) => (
              <TableRow key={index}>
                <TableCell align="left">{row.name}</TableCell>
                <TableCell align="left">{row.email}</TableCell>
                <TableCell align="left">{row.phone}</TableCell>
                <TableCell align="left">{row.age}</TableCell>
                <TableCell align="left">{row.gender}</TableCell>
                <TableCell align="left">{row.address}</TableCell>
                <TableCell align="left">
                  <EditIcon className={classes.cursorStyle} onClick={() => editStudent(row.id)}/>
                  &nbsp; 
                  <DeleteIcon className={classes.cursorStyle} onClick={() => deleteStudent(row.id)}/>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog
              open={state.open}
              onClose={handleClose}
              aria-labelledby="alert-dialog-title"
              aria-describedby="alert-dialog-description"
          >
          <DialogContent dividers>
             <Register history={props.history} data={state.studentData} isstudentListPage flex="0 0 100%"/>
          </DialogContent>
          <DialogActions>
              <Button autoFocus onClick={handleClose} color="primary">
                  Close
              </Button>
          </DialogActions>
      </Dialog>
    </>
  );
}
export default StudentList;
