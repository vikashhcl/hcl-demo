/*
Component Name: SubscriberList
Author: Vikash Rawshan : 51904199
Description : This is functional component used to display list of subscribed user details
Key Feature : I used new Hook features like useEffect,useSelector, useDispatch, and Material UI
*/
import {useEffect} from 'react';
import {useSelector, useDispatch} from 'react-redux';
import {getSubscribedList} from '../../action/student/subscribe';
import { makeStyles } from '@material-ui/core/styles';
import {Table,TableBody,TableCell, TableContainer, TableHead, TableRow} from '@material-ui/core';

const useStyles = makeStyles({
  table: {
    justifyContent: 'center',
    width:'50%',
    margin: 'auto'
  },
  trBoldText : {
    fontWeight: 600
  },
  cursorStyle :{
    cursor : 'pointer'
  }
});

const SubscriberList = (props) => {
  const classes = useStyles();  
  const {subscribedList} = useSelector(state => state.subscribeReducer);
  const {userData : {isLoggedin}} = useSelector(state => state.loginReducer);
  const dispatch = useDispatch();

  if(!isLoggedin){
      props.history.replace('./')
  }

  /*
    Validation Schema Name: getSubscribedList
    Author: Vikash Rawshan : 51904199
    Description : Here we are dispatching an action dispatcher getSubscribedList to get subscriber list
  */
  useEffect(()=>{
    dispatch(getSubscribedList())
  },[]);
  
  return (
    <>
      <TableContainer>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
                <TableCell align="center" colSpan={3} className={classes.trBoldText}>
                  Subscriber List
                </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className={classes.trBoldText}>ID</TableCell>
              <TableCell align="left" className={classes.trBoldText}>Email ID</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {subscribedList.map((row, index) => (
              <TableRow key={index}>
                <TableCell align="left">{row.id}</TableCell>
                <TableCell align="left">{row.email}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
}
export default SubscriberList;
