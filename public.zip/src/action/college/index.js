/*
Action Name: College Action
Author: Vikash Rawshan : 51904199
Description : This file is used to handle college module action dispatcher
*/
import axios from 'axios';
import { COLLEGE_LIST_API, ENROLLED_API } from "../../common/constant";

export const sendRequest = (data) => {
    return (dispatch) =>{
        axios.post(ENROLLED_API,data)
        .then(response => {
            if(response.status == 201){
                dispatch({type: 'UPDATE_REQUEST_STATUS', payload: true})
                data.userType == 0 ? dispatch(getEnrolledList(data.userName)) : dispatch(getEnrolledList())
            }
        })
        .catch( error => {
            console.log("Failed : "+ error);
        })
    }
}

export const getEnrolledList = (id) => {
    const query = (id != undefined) ? "?userName="+id : ''
    return (dispatch) => {
        axios.get(ENROLLED_API+query)
        .then(response =>{
            dispatch({
                type: 'ENROLLED_LIST',
                payload: response.data
            })
        })
        .catch(error => {
            console.log(error)
        })
    }
}

export const cancelStudentRequest = (data) =>{
    return (dispatch) => {
        axios.delete(ENROLLED_API+"/"+data.id)
        .then (response =>{
            if(response.status == 200){
                (data.userType == 0) ? dispatch(getEnrolledList(data.userName)) : dispatch(getEnrolledList())
            }
        })
        .catch(error =>{
            console.log(error,"Failed to get college list");
        })
    }
}

export const changeRequestStatus = (data) => {
    return (dispatch) =>{
        axios.patch(ENROLLED_API+"/"+data.id, {requestStatus : data.status})
        .then(response => {
            dispatch(getEnrolledList())
        })
        .catch(error =>{
            console.log(error)
        })
    }
}

export const updateCollegeList = (data) =>{
    return {
        type : 'UPDATE_COLLEGE_LIST',
        payload : data
    }
}

export const getCollegeList = (city) => {
    const query = (city != 'all') ? "?city="+city : '';
    return (dispatch) => {
        axios.get(COLLEGE_LIST_API+query)
        .then(response => {
            dispatch(updateCollegeList(response.data));
        }).catch( error => {
            console.log(error);
        });
    }
}

export const setModalShow = (data) => {
    return {
        type: 'CLOSE_MODAL',
        payload: data
    }
}