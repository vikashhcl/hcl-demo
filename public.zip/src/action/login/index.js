/*
Action Name: Login Action
Author: Vikash Rawshan : 51904199
Description : This file is used to handle login module action dispatcher
*/
import axios from 'axios';
import { USER_DETAILS_API } from "../../common/constant";
import {getCollegeList, getEnrolledList} from '../../action/college'

export const checkUSerAuth = (data) => {
    return (dispatch) => {
        const query = "?userName="+data.username+"&password="+data.password;
        axios.get(USER_DETAILS_API+query)
        .then(response => {
            if(response.data.length > 0){
                dispatch(updateUserDetails(response.data));            
                response.data[0].user_type == 0 ? dispatch(getEnrolledList(data.user_id)) : dispatch(getEnrolledList())
                // dispatch(getCollegeList('All'))
            }else{
                dispatch(loginFailed())
            }            
        }).catch( error => {
            dispatch(loginFailed())
        });
    }
}

export const updateUserDetails = (data) => {
    return {
       type: 'UPDATE_USER_DETAIL',
       payload: data
    }
}

export const userLogout = (data) => {
    return {
       type: 'USER_LOGOUT',
       payload: data
    }
}

export const loginFailed = () =>{
    return {
        type: 'LOGIN_FAILED',
        payload: false
    }
}