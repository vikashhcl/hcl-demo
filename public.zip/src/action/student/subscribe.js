/*
Action Name: Subscriber Action
Author: Vikash Rawshan : 51904199
Description : This file is used to handle Subscriber module action dispatcher
*/
import axios from 'axios';
import { SUBSCRIBE_API } from "../../common/constant";

export const subscribeUser = (data) => {
    return (dispatch) => {
        axios.post(SUBSCRIBE_API, {email:data})
        .then(response => {
            if(response.status === 201){
                dispatch({type :'SUBSCRIBE_USER', payload: true});
            }           
        }).catch( error => {
            console.log(error," :: ERROR ")
        });  
    }
}

export const getSubscribedList = () =>{
    return (dispatch) => {
        axios.get(SUBSCRIBE_API)
        .then(response => {
            dispatch(updateSubscribedList(response.data))
        })
        .catch( error =>{
            console.log(error," :: ERROR ")
        })
    }
}

export const updateSubscribedList = (data) => {
    return {
       type: 'UPDATE_SUBSCRIBER_LIST',
       payload: data
    }
}

export const closeModel = () =>{
    return {
        type: 'CLOSE_MODEL'
    }
}