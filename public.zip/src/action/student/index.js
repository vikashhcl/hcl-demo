/*
Action Name: Student Action
Author: Vikash Rawshan : 51904199
Description : This file is used to handle student module action dispatcher
*/
import axios from 'axios';
import { USER_REGISTER_API } from "../../common/constant";

export const studentRegister = (id, studentData) => {
    return (dispatch) => {
        if(id !== null){
            axios.patch(USER_REGISTER_API+"/"+id, studentData)
            .then(response => {
                if(response.status === 200){
                    dispatch(updateStudentDetails(true));
                    dispatch(getStudentList());
                }           
            }).catch( error => {
                console.log(error," :: ERROR ")
            });
        }else{
            axios.post(USER_REGISTER_API, studentData)
            .then(response => {
                if(response.status === 201){
                    dispatch({type :'REGISTER_STUDENT', payload: true});
                }           
            }).catch( error => {
                console.log(error," :: ERROR ")
            });
        }        
    }
}

export const getStudentList = (id) =>{
    return (dispatch) => {
        axios.get(USER_REGISTER_API)
        .then(response => {
            dispatch(updateRegistrationDetails(response.data))
        })
        .catch( error =>{
            console.log(error," :: ERROR ")
        })
    }
}

export const deleteStudentEntry = (id) =>{
    return (dispatch) => {
        axios.delete(USER_REGISTER_API+"/"+id)
        .then(response => {
            dispatch(getStudentList());
        })
        .catch( error =>{
            console.log(error," :: ERROR ")
        })
    }
}

export const updateStudentDetails = (data) => {
    return {
       type: 'UPDATE_STUDENT_DETAIL',
       payload: data
    }
}

export const updateRegistrationDetails = (data) => {
    return {
       type: 'UPDATE_REGISTRATION_DETAIL',
       payload: data
    }
}