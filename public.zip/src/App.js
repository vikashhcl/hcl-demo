import {Suspense, lazy} from 'react';
import './App.css';
import {Route, BrowserRouter, Switch} from 'react-router-dom';
const Header = lazy(() => import('../src/common/Header'));
const Home = lazy(() => import('../src/components/home'));
const Login = lazy(() => import('../src/components/login'));
const CollegeList = lazy(() => import('../src/components/College/CollegeList'));
const Register = lazy(() => import('./components/student'));
const StudentList = lazy(() => import('./components/student/studentList'));
const EnrolledList = lazy(() => import('./components/College/enrolledList'));
const SubscriberList = lazy(() => import('./components/student/subscriber'));

function App() {
  return (
    <>
      <BrowserRouter>
            <Suspense fallback={<div style={{textAlign:'center', marginTop:'100px'}}>Loading...</div>}>
            <Header/>
              <Switch>
                  <Route exact path = "/login" component = {Login}/>
                  <Route exact path = "/" component = {Home}/>
                  <Route exact path = "/collegelist" component = {CollegeList}/>
                  <Route exact path = "/register" component = {Register}/>
                  <Route exact path = "/studentlist" component = {StudentList}/>
                  <Route exact path = "/enrolledlist" component = {EnrolledList}/>
                  <Route exact path = "/subscriber" component = {SubscriberList}/>
              </Switch>
              </Suspense>
        </BrowserRouter>
    </>
  );
}

export default App;
